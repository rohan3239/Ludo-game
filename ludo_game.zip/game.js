const socket = io();

document.getElementById("rollDice").addEventListener("click", () => {
    socket.emit("rollDice");
});

socket.on("diceResult", (result) => {
    document.getElementById("diceResult").innerText = `You rolled: ${result}`;
});
